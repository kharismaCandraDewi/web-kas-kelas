<?php

namespace App\Http\Controllers;

use App\Models\Pembayaran;
use App\Models\Siswa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class PembayaranController extends Controller
{
    public function index()
    {
        //get pembayaran
        $pembayaran = Pembayaran::latest()->paginate(5);
        $siswa = Siswa::all();
        //render view with pembayaran
        return view('pembayaran.index', compact('pembayaran', 'siswa'));
    }

    public function create()
    {
        $siswa = Siswa::all();
        return view('pembayaran.create', compact('siswa'));
    }

        /**
         * store
         * 
         * @param Request $request
         * @return void
         */

         public function store(Request $request)
         {
            //validate form

            $this->validate($request, [
                'id_siswa' => 'required|min:1',
                'tgl_bayar' => 'required|date',
                'jumlah_bayar' => 'required|numeric',
            ]);

            //check if a record exists,update it
            $existingRecord = Pembayaran::where('id_siswa', $request->id_siswa)->first();

            if($existingRecord) {
                //If the record exists, update it
                $existingRecord->update([
                    'tgl_bayar' => $request->tgl_bayar,
                    'jumlah_bayar' => $existingRecord->jumlah_bayar + $request->jumlah_bayar,
                ]);

                // Redirect to index with success message
                return redirect()->route('pembayaran.index')->with(['success' => 'Data Berhasil Diupdate!']);
            } else {    
                // If the record does not exist, create a new one
                pembayaran::create([
                    'id_siswa' => $request->id_siswa,
                    'tgl_bayar' => $request->tgl_bayar,
                    'jumlah_bayar' => $request->jumlah_bayar,
                ]);

                 //Redirect to index with success message
                 return redirect()->route('pembayaran.index')->with(['success' => 'Data Berhasil Disimpan!']);
            }
            //create post
            Pembayaran::create([
                'id_siswa' => $request->input('id_siswa'),
                'tgl_bayar' => $request->input('tgl_bayar'),
                'jumlah_bayar' => $request->input('jumlah_bayar'),
        ]);

            //redirect to index
            return redirect()->route('pembayaran.index')->with(['success' => 'Pembayaran Berhasil Disimpan!']);
         }

         public function destroy(Pembayaran $pembayaran)
         {
             $pembayaran->delete();
             //redirect to index
             return redirect()->route('pembayaran.index')->with(['success' => 'Data Berhasil Dihapus!']);
     }
}

