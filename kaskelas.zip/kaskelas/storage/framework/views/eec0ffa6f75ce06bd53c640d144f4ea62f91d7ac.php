<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charseat="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie-edge">
        <title>Data pembayaran - Kas Kelas</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    </head>
    <body style="background: lightgrey">
        
        <div class="container mt-5 mt-5">
            <div class="row">
                <div class="col-md-12">
                    <div class="card border-0 shadow rounded">
                        <div class="card-body">
                            <form action="<?php echo e(route('pembayaran.store')); ?>" method="POST" enctype="multipart/form-data">
                            
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="exampleDropdown" class="font-weight-bold">Siswa</label>
                                    <select name="id_siswa" class="form-control" id="exampleDropDown">
                                        <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?> - <?php echo e($item->kelas); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                    <!-- error message untuk title -->
                                <div class="form-group">
                                    <label class="font-weight-bold">Tanggal Bayar</label>
                                    <input type="date" class="form-control" name="tgl_bayar" placeholder="Masukkan Nama" pattern="\d{4}-\d{2}-\d{2}">

                                    <!-- error message untuk title -->
                                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger mt-2">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="form-group">
                                    <label class="font-weight-bold">Jumlah Bayar</label>
                                    <input type="text" class="form-control"name="jumlah_bayar" placeholder="Masukkan Nominal Bayar">
                                </div>

                                <!-- error message untuk content -->
                                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-2">
                                        <?php echo e($mesage); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                                <button type="submit" class="btn btn-md btn-primary">SIMPAN</button>
                                <button type="reset" class="btn btn-md btn-warning">RESET</button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>
    </body>
</html><?php /**PATH E:\laragon\www\project kls12\kaskelas\resources\views/pembayaran/create.blade.php ENDPATH**/ ?>