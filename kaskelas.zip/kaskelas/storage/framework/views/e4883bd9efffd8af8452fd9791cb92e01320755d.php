<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Data Posts - DataSiswa.com</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
</head>
<body style="background: lightgray">

    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                        <a href="<?php echo e(route('pembayaran.create')); ?>" class="btn btn-md btn-success mb-3">Bayar Kas</a>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th scope="col">Nama</th>
                                    <th scope="col">Tanggal Terakhir Bayar</th>
                                    <th scope="col">Total Bayar</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pembayaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($pembayaran->siswa->nama); ?></td>
                                        <td style="width: 150px;"><?php echo e(\Carbon\Carbon::parse($pembayaran->tgl_bayar)->formatLocalized('%d %B %Y')); ?></td>
                                        <td style="width: 150px;">Rp. <?php echo e(number_format($pembayaran->jumlah_bayar,0)); ?></td>
                                        <td> 
                                            <form onsubmit="return confirm('Apakah Anda Yakin ?');" action="<?php echo e(route('pembayaran.destroy', $pembayaran->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger">Hapus<i data-feather="delete"></button>
                                        </form>
                                    </td>
                                        </td>
                                    </tr>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="alert alert-danger">
                                            Data Pembayaran Belum Tersedia.
                                        </div> 
                                <?php endif; ?>
                            </tbody>
                        </table>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <script>
        //mesage with toastr
        <?php if(session()->has('success')): ?>

            toastr.error('<?php echo e(session('success')); ?>', 'BERHASIL!');
        
        <?php elseif(session()->has('error')): ?>

            toastr.error('<?php echo e(session('error')); ?>', 'GAGAL!');

        <?php endif; ?>
    </script>
    <script>
        feather.replace();
        </script>
    </body>
    </html><?php /**PATH E:\laragon\www\project kls12\kaskelas\resources\views/pembayaran/index.blade.php ENDPATH**/ ?>